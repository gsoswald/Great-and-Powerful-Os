Great-and-Powerful-Os
=====================

Texture for our minecraft server
