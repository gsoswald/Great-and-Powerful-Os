Or language pack was designed and created by Disaster86.
It is cross compatible with an upcoming Soartex Texture Pack, and Disaster86's vonDoomCraft language pack.

To install, extract this folder to /minecraft.jar/lang
If you like the idea of Automatic language pack installation, ask nicely for Kahr to include it in MCPatcher :)

If you run multiple language packs, add this to your languages.txt in /minecraft.jar/lang:

en_SX=English (Soartex Standard)
